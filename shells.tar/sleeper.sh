#!/bin/bash


sleep 100
tar cvf /tmp/lessons.tar  /var/www/html/lessons >& /dev/null
